# EVT E3 平顶版贴片前复核 · 2026-09-08

结论：本地工程检查通过；实际订单匹配、齐料、工厂 DFM 和首板实测待完成，尚非量产放行。

## 上传文件

解压 ir_glasses_EVT_E3_JLC_upload.zip 后，分别上传：

1. 01_Gerber_carrier.zip：带载框加工文件，四层 FR-4、1.6 mm、沉金，5 块裸板。
2. 02_BOM.csv：33 类、142 个贴装位号；数量为每板数量，订单设 2 块同配置贴片。
3. 03_CPL.csv：142 位号，全部 Top，坐标单位 mm；与载框一致，无需平移。

其余文件供装配方向和载框审核。不要直接上传本外层资料 ZIP 作为 Gerber。
J2 下载器触点、测试点及机械孔无需贴片，不在 BOM/CPL 中。
J1 无 C 编码，必须按 TE 2492111-5 自备料处理；不可删除其 BOM 行而保留坐标。

## 封装字段修正

IR_Glasses: 是 KiCad 本地库名称，工程内保留它以正确加载专用符号和封装。
此前工程 BOM 混入库前缀，贴片表又沿用了 KiCad 长名称，确实容易影响识别。
现在全部 BOM 的 Footprint 和坐标表的 Package 使用 0402、0603、TSSOP-14 等规格；已从表格中彻底移除 KiCad_Library_ID 列。
上传文件不包含这些库 ID。应按完整型号和 LCSC Part # 匹配，核对平台最终匹配的厂家、型号和封装。

| 器件 | 上传封装 | 必须保留的区别 |
|---|---|---|
| PD15-21B/TR8 | 1206 | 专用焊盘，1=A/GND，2=K/PD_IN |
| IR11-21C/TR8 | 1206 | 专用光学封装，1=A/3V3，2=K/LED_K |
| TLV9064IPWR | TSSOP-14 | 不可换为 IDR 的 SOIC |
| TPS259470LRPWR | VQFN-10-HR(2x2) | RPW0010A 专用焊盘，不是普通 QFN-10 |
| J1 2492111-5 | FFC/FPC-5P-P0.5mm | 上接触、0.3 mm 排线，指定型号自备 |

1206/0402 等使用英制封装编号；不要在 Excel 中把 0402 转成数字 402 后另存。
修改 BOM、坐标或 Gerber 后，需重新导入配套文件并重新执行匹配和 SMT 检查。
规则来源：https://www.jlc.com/portal/server_guide_48022.html

## 本次检查结果

- 新运行 KiCad 10 ERC：0；单板 DRC：0、未连接：0、原理图一致性：0；载框 DRC：0、未连接：0。
- 原生 PCB、网络表与 BOM 核对通过；142 个贴装位号均在正面，33 类物料，两板净用 284 颗。
- 16 路 PD/LED 极性、网络及位置角度检查通过；PD 两板净用 32 颗。
- 中央 IMU、双眼开孔保持；载框与单板焊盘、走线及 142 个贴片坐标对应一致。
- 467 个贴装铜焊盘、470 个钢网开口（U1 散热焊盘分窗），341 个过孔。
- 本次仅修改导出字段和交付组织；PCB 与已审阅 CAM/预览通过 SHA256 验证一致，未改变板形、走线或贴装角度。
- 单板 SHA256：935e036ae540a0a570e9094cff8fdfb2eeac0c8aeb9bcddc5d543caf8f71a6c1。
- 载框 SHA256：b2e7d6b8965b5950614304b614e21c66394979618ad2704ae9c257a01225c139。

DRC 零违规是在当前项目规则下取得。继承忽略项包括 missing_courtyard、track_not_centered_on_via、
tuning_profile_track_geometries、footprint_filters_mismatch、footprint_type_mismatch；
ERC 亦忽略单个全局标签、四向结点、仿真模型及封装筛选提示。完整列表见 erc.json/drc.json。
这些本地检查不代替工厂钢网、可焊性和元件匹配审核。

## 尚未完成的生产条件

- IR LED 采购改用用户提供的 C19269752：已核对为 Everlight IR11-21C/TR8、1206，与原选型一致。用户报告国内库存充足，订单锁料和损耗待确认。原 C16745 查询结果不能代表该型号全部供货情况。
  来源：https://www.lcsc.com/product-detail/C19269752.html
- PCB 内历史采购属性 C16745 保留，现行采购编码以 BOM 的 C19269752 为准；电气型号和焊盘不变。其余国内齐料及平台损耗尚待订单确认。
- J1 自备料接收、各封装平台贴装角度、PD/LED 极性、QFN/LGA 钢网和回流、载框分板 DFM 均待工厂确认。
- 固件 HEX/BIN 尚未提供；E3 的 PB2 LED_ENABLE 为高有效，不能直接沿用旧版控制极性。
- 供电应为 3.20–3.40 V；R18/R19 指定 0.1% 精度不可降级。状态灯为 MCU 控制，未烧程序时不保证亮。
- 首板仍须完成供电、保护动作、SWD/UART、IMU、16 路暗态/照光、饱和、串扰和建立时间测试；状态灯在光学采样期间关闭。
- 重复触发占空比和眼部光学安全不能仅靠脉冲限时电路保证，尚未进行实测验证。

本次没有执行嘉立创账户内的实际匹配、下单或付款。全套 first_board_tests.csv 和 release_checklist.csv 保持有效。
